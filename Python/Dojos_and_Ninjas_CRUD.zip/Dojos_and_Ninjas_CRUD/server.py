from app import app
from app.controllers import ninjas

if __name__ == "__main__":
    app.run(debug=True)
