from app import app
from app.controllers import ninjas
from app.controllers import dojos

if __name__ == "__main__":
    app.run(debug=True)
