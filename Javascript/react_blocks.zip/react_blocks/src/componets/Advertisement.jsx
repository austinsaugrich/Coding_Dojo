const Advertisment = () => {
    return(
        <div className="adv">
            
        </div>
    )
} 
export default Advertisment;
