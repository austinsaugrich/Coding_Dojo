const Nav = () => {
    return(
        <div className="nav">
            
        </div>
    )
} 
export default Nav;
