import Pokemon from './components/pokemon'
import './App.css'

function App(){
  return (
    <div>
      <Pokemon/>
    </div>
  )
}

export default App